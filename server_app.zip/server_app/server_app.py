import os
import time
import math
import socket
import json
import tempfile
import threading
from flask import Flask, jsonify, request, Response
import psutil
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST, Gauge, Counter

app = Flask(__name__)

SERVER_ID = os.environ.get("SERVER_ID", "SERVER_A")
SERVER_PORT = int(os.environ.get("SERVER_PORT", 5001))
IS_PRIMARY = os.environ.get("IS_PRIMARY", "true").lower() == "true"
SERVER_ROLE = os.environ.get("SERVER_ROLE", "PRIMARY" if IS_PRIMARY else "BACKUP")

# Monotonic Request & Dynamic Simulation State Variables
simulation_state = {
    "cpu_active": False,
    "ram_allocated": [],
    "disk_allocated_mb": 0,
    "latency_seconds": 0.0,
    "error_rate": 0.0,
    "is_outage": False,
    "total_requests": 0,
    "active_requests": 0,
    "successful_requests": 0,
    "failed_requests": 0,
    "error_count": 0,
    "start_time": time.time(),
    "last_request_time": time.time(),
    "total_response_time_ms": 0.0
}

# Prometheus Metrics
PROM_CPU = Gauge('server_cpu_usage_percent', 'CPU Usage Percentage', ['server_id'])
PROM_MEM = Gauge('server_memory_usage_percent', 'Memory Usage Percentage', ['server_id'])
PROM_DISK = Gauge('server_disk_usage_percent', 'Disk Usage Percentage', ['server_id'])
PROM_LATENCY = Gauge('server_response_latency_seconds', 'Response Latency in Seconds', ['server_id'])
PROM_ERROR_RATE = Gauge('server_error_rate_ratio', 'Error Rate Ratio', ['server_id'])
PROM_HEALTH = Gauge('server_health_status', 'Server Health Status 1=Healthy 0=Outage', ['server_id'])
PROM_REQUESTS = Counter('server_total_requests_count', 'Total HTTP Requests Served', ['server_id'])

# CPU Stress Worker Thread
def cpu_stress_worker():
    while simulation_state["cpu_active"]:
        _ = math.factorial(25000)
        time.sleep(0.001)

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'

def calculate_dynamic_health_score(cpu, mem, disk, latency_ms, error_rate):
    if simulation_state["is_outage"]:
        return 0.0
        
    lat_penalty = min(100.0, (latency_ms / 2000.0) * 100.0)
    err_penalty = min(100.0, error_rate * 100.0)
    
    penalty = (0.30 * cpu) + (0.30 * mem) + (0.10 * disk) + (0.15 * lat_penalty) + (0.15 * err_penalty)
    score = max(0.0, min(100.0, 100.0 - (penalty * 0.6)))
    return round(score, 1)

@app.before_request
def handle_simulated_delays_and_errors():
    request.start_time_ms = time.time() * 1000.0
    simulation_state["total_requests"] += 1
    simulation_state["active_requests"] += 1
    simulation_state["last_request_time"] = time.time()
    # Dynamic Request Concurrency Load Scaling:
    # High concurrent HTTP requests naturally increase queuing delay and CPU compute load
    if simulation_state["active_requests"] > 8:
        concurrency_delay = min(5.5, (simulation_state["active_requests"] - 8) * 0.12)
        time.sleep(concurrency_delay)
        _ = math.factorial(15000)

    # Latency injection
    if simulation_state["latency_seconds"] > 0:
        time.sleep(simulation_state["latency_seconds"])

    # Error injection (skip management routes)
    if request.path not in ["/health", "/api/metrics", "/metrics", "/status", "/simulate/recover"]:
        if simulation_state["is_outage"]:
            simulation_state["failed_requests"] += 1
            simulation_state["error_count"] += 1
            simulation_state["active_requests"] = max(0, simulation_state["active_requests"] - 1)
            return jsonify({"error": "Simulated Outage Active", "server_id": SERVER_ID}), 503

        if simulation_state["error_rate"] > 0:
            import random
            if random.random() < simulation_state["error_rate"]:
                simulation_state["failed_requests"] += 1
                simulation_state["error_count"] += 1
                simulation_state["active_requests"] = max(0, simulation_state["active_requests"] - 1)
                return jsonify({"error": "Simulated Fault Injection", "server_id": SERVER_ID}), 500

@app.after_request
def apply_headers_and_cleanup(response):
    simulation_state["active_requests"] = max(0, simulation_state["active_requests"] - 1)
    if response.status_code < 400:
        simulation_state["successful_requests"] += 1
        
    duration = (time.time() * 1000.0) - getattr(request, 'start_time_ms', time.time() * 1000.0)
    simulation_state["total_response_time_ms"] += duration
    
    # CRITICAL SECTION 16.1 REQUIREMENT: Proof Headers
    response.headers["X-Served-By"] = SERVER_ID
    response.headers["X-Server-Port"] = str(SERVER_PORT)
    response.headers["X-Request-Number"] = str(simulation_state["total_requests"])
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Expose-Headers"] = "X-Served-By, X-Server-Port, X-Request-Number"
    return response

@app.route("/health", methods=["GET"])
def health_check():
    cpu = psutil.cpu_percent(interval=None)
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent
    lat_ms = simulation_state["latency_seconds"] * 1000.0
    err_rate = (simulation_state["error_count"] / max(1, simulation_state["total_requests"])) if simulation_state["total_requests"] > 0 else 0.0
    if simulation_state["error_rate"] > 0:
        err_rate = max(err_rate, simulation_state["error_rate"])
        
    health_score = calculate_dynamic_health_score(cpu, mem, disk, lat_ms, err_rate)
    
    is_unhealthy = (
        simulation_state["is_outage"] or 
        cpu >= 95.0 or 
        mem >= 90.0 or 
        lat_ms >= 5000.0 or 
        err_rate >= 0.30 or 
        health_score < 40.0
    )
    is_healthy = not is_unhealthy
    
    status_str = "HEALTHY" if is_healthy else "UNHEALTHY"
    status_code = 200 if is_healthy else 503
    
    PROM_HEALTH.labels(server_id=SERVER_ID).set(1 if is_healthy else 0)
    return jsonify({
        "status": status_str,
        "health_score": health_score,
        "server_name": SERVER_ID,
        "server_id": SERVER_ID,
        "role": SERVER_ROLE,
        "port": SERVER_PORT,
        "is_primary": IS_PRIMARY,
        "total_requests": simulation_state["total_requests"],
        "active_requests": simulation_state["active_requests"],
        "successful_requests": simulation_state["successful_requests"],
        "failed_requests": simulation_state["failed_requests"],
        "uptime": int(time.time() - simulation_state["start_time"]),
        "last_request_time": simulation_state["last_request_time"],
        "cpu": round(cpu, 2),
        "memory": round(mem, 2),
        "disk": round(disk, 2),
        "latency": round(lat_ms, 2),
        "error_rate": round(err_rate, 4)
    }), status_code

@app.route("/api/metrics", methods=["GET"])
@app.route("/status", methods=["GET"])
def get_metrics():
    cpu = psutil.cpu_percent(interval=None)
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent
    net = psutil.net_io_counters()
    
    uptime_sec = int(time.time() - simulation_state["start_time"])
    lat_ms = round(simulation_state["latency_seconds"] * 1000.0, 2)
    
    err_rate = (simulation_state["error_count"] / max(1, simulation_state["total_requests"])) if simulation_state["total_requests"] > 0 else 0.0
    if simulation_state["error_rate"] > 0:
        err_rate = max(err_rate, simulation_state["error_rate"])
    err_rate = round(err_rate, 4)
    
    health_score = calculate_dynamic_health_score(cpu, mem, disk, lat_ms, err_rate)
    
    is_unhealthy = (
        simulation_state["is_outage"] or 
        cpu >= 95.0 or 
        mem >= 90.0 or 
        lat_ms >= 5000.0 or 
        err_rate >= 0.30 or 
        health_score < 40.0
    )
    
    if is_unhealthy:
        status_label = "UNHEALTHY"
    elif health_score < 75.0 or cpu > 70.0 or mem > 70.0:
        status_label = "WARNING"
    else:
        status_label = "HEALTHY"

    avg_resp = (simulation_state["total_response_time_ms"] / max(1, simulation_state["total_requests"])) if simulation_state["total_requests"] > 0 else lat_ms + 12.0

    metrics_data = {
        "server_name": SERVER_ID,
        "server_id": SERVER_ID,
        "role": SERVER_ROLE,
        "server_port": SERVER_PORT,
        "port": SERVER_PORT,
        "is_primary": IS_PRIMARY,
        "status": status_label,
        "health_score": health_score,
        "cpu_percent": round(cpu, 2),
        "cpu": round(cpu, 2),
        "memory_percent": round(mem, 2),
        "memory": round(mem, 2),
        "disk_percent": round(disk, 2),
        "disk": round(disk, 2),
        "network_sent_mb": round(net.bytes_sent / (1024 * 1024), 2),
        "network_recv_mb": round(net.bytes_recv / (1024 * 1024), 2),
        "latency_ms": lat_ms,
        "latency": lat_ms,
        "response_time_ms": round(avg_resp, 2),
        "response_time": round(avg_resp, 2),
        "average_response_time": round(avg_resp, 2),
        "error_rate": err_rate,
        "total_requests": simulation_state["total_requests"],
        "request_count": simulation_state["total_requests"],
        "active_requests": simulation_state["active_requests"],
        "successful_requests": simulation_state["successful_requests"],
        "failed_requests": simulation_state["failed_requests"],
        "error_count": simulation_state["error_count"],
        "uptime": uptime_sec,
        "uptime_seconds": uptime_sec,
        "last_request_time": simulation_state["last_request_time"],
        "active_simulations": {
            "cpu_stress": simulation_state["cpu_active"],
            "ram_allocated_mb": len(simulation_state["ram_allocated"]) * 50,
            "disk_allocated_mb": simulation_state["disk_allocated_mb"],
            "latency_injected_sec": simulation_state["latency_seconds"],
            "error_rate_injected": simulation_state["error_rate"],
            "is_outage": simulation_state["is_outage"]
        }
    }
    
    PROM_CPU.labels(server_id=SERVER_ID).set(metrics_data["cpu_percent"])
    PROM_MEM.labels(server_id=SERVER_ID).set(metrics_data["memory_percent"])
    PROM_DISK.labels(server_id=SERVER_ID).set(metrics_data["disk_percent"])
    PROM_LATENCY.labels(server_id=SERVER_ID).set(simulation_state["latency_seconds"])
    PROM_ERROR_RATE.labels(server_id=SERVER_ID).set(metrics_data["error_rate"])
    PROM_HEALTH.labels(server_id=SERVER_ID).set(0 if is_unhealthy else 1)
    
    return jsonify(metrics_data)

HTML_INDEX_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{server_id} — Target Node Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Outfit', sans-serif;
            background: #0f172a;
            color: #f8fafc;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}
        .container {{
            width: 100%;
            max-width: 900px;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 28px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #334155;
            margin-bottom: 24px;
        }}
        .server-title {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .server-name {{
            font-size: 1.8rem;
            font-weight: 800;
            color: #38bdf8;
        }}
        .badge-role {{
            background: #1e1b4b;
            color: #a78bfa;
            border: 1px solid #6366f1;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 700;
        }}
        .status-pill {{
            display: flex;
            align-items: center;
            gap: 8px;
            background: #064e3b;
            color: #34d399;
            border: 1px solid #10b981;
            padding: 6px 16px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9rem;
        }}
        .status-dot {{
            width: 10px;
            height: 10px;
            background: #34d399;
            border-radius: 50%;
            box-shadow: 0 0 10px #34d399;
            animation: pulse 1.5s infinite;
        }}
        @keyframes pulse {{
            0% {{ transform: scale(0.95); opacity: 0.8; }}
            50% {{ transform: scale(1.15); opacity: 1; }}
            100% {{ transform: scale(0.95); opacity: 0.8; }}
        }}
        .proof-box {{
            background: #0f172a;
            border: 1px dashed #6366f1;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 24px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.88rem;
        }}
        .proof-title {{
            color: #818cf8;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }}
        .proof-grid {{
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
        }}
        .proof-item span {{
            color: #94a3b8;
        }}
        .proof-item strong {{
            color: #38bdf8;
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }}
        .card {{
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 16px;
        }}
        .card-label {{
            color: #94a3b8;
            font-size: 0.85rem;
            margin-bottom: 6px;
        }}
        .card-value {{
            font-size: 1.6rem;
            font-weight: 700;
            color: #f8fafc;
        }}
        .bar-bg {{
            background: #334155;
            height: 6px;
            border-radius: 3px;
            margin-top: 8px;
            overflow: hidden;
        }}
        .bar-fill {{
            height: 100%;
            background: linear-gradient(90deg, #38bdf8, #818cf8);
            width: 0%;
            transition: width 0.3s ease;
        }}
        .actions {{
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }}
        .btn {{
            background: #334155;
            color: #f8fafc;
            border: 1px solid #475569;
            padding: 10px 16px;
            border-radius: 8px;
            font-family: inherit;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .btn:hover {{
            background: #475569;
            border-color: #38bdf8;
        }}
        .btn-danger {{
            background: #7f1d1d;
            border-color: #ef4444;
            color: #fca5a5;
        }}
        .btn-danger:hover {{
            background: #991b1b;
        }}
        .btn-success {{
            background: #064e3b;
            border-color: #10b981;
            color: #6ee7b7;
        }}
        .btn-success:hover {{
            background: #047857;
        }}
        .raw-json {{
            display: none;
            background: #090d16;
            border: 1px solid #334155;
            padding: 16px;
            border-radius: 10px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.85rem;
            color: #34d399;
            white-space: pre-wrap;
            margin-top: 16px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="server-title">
                <div class="server-name">{server_id}</div>
                <div class="badge-role">{role}</div>
            </div>
            <div class="status-pill" id="statusPill">
                <div class="status-dot" id="statusDot"></div>
                <span id="statusText">HEALTHY</span>
            </div>
        </div>

        <div class="proof-box">
            <div class="proof-title">🔒 Evaluator Independent Proof Headers (X-Headers)</div>
            <div class="proof-grid">
                <div class="proof-item"><span>X-Served-By:</span> <strong id="hdrServedBy">{server_id}</strong></div>
                <div class="proof-item"><span>X-Server-Port:</span> <strong id="hdrPort">{server_port}</strong></div>
                <div class="proof-item"><span>X-Request-Number:</span> <strong id="hdrReqNum">{total_requests}</strong></div>
            </div>
        </div>

        <div class="grid">
            <div class="card">
                <div class="card-label">Total Requests Served</div>
                <div class="card-value" id="valTotalReq">{total_requests}</div>
            </div>
            <div class="card">
                <div class="card-label">CPU Usage</div>
                <div class="card-value" id="valCpu">{cpu}%</div>
                <div class="bar-bg"><div class="bar-fill" id="barCpu" style="width: {cpu}%;"></div></div>
            </div>
            <div class="card">
                <div class="card-label">Memory Usage</div>
                <div class="card-value" id="valMem">{memory}%</div>
                <div class="bar-bg"><div class="bar-fill" id="barMem" style="width: {memory}%;"></div></div>
            </div>
            <div class="card">
                <div class="card-label">Network Latency</div>
                <div class="card-value" id="valLat">{latency} ms</div>
            </div>
        </div>

        <div class="actions">
            <button class="btn" onclick="triggerStress('cpu')">⚡ Inject CPU Stress</button>
            <button class="btn" onclick="triggerStress('latency')">🐢 Inject 5.5s Latency</button>
            <button class="btn btn-danger" onclick="triggerOutage()">💥 Simulate Outage</button>
            <button class="btn btn-success" onclick="triggerRecover()">💚 Recover Node</button>
            <button class="btn" onclick="toggleJson()">📜 Toggle Raw JSON View</button>
        </div>

        <pre class="raw-json" id="jsonBox">{raw_json}</pre>
    </div>

    <script>
        async function updateMetrics() {{
            try {{
                const res = await fetch('/api/metrics');
                const d = await res.json();
                document.getElementById('valTotalReq').innerText = d.total_requests;
                document.getElementById('valCpu').innerText = d.cpu + '%';
                document.getElementById('barCpu').style.width = Math.min(100, d.cpu) + '%';
                document.getElementById('valMem').innerText = d.memory + '%';
                document.getElementById('barMem').style.width = Math.min(100, d.memory) + '%';
                document.getElementById('valLat').innerText = d.latency + ' ms';
                document.getElementById('hdrReqNum').innerText = d.total_requests;
                document.getElementById('jsonBox').innerText = JSON.stringify(d, null, 2);
                
                const pill = document.getElementById('statusPill');
                const txt = document.getElementById('statusText');
                if (d.status === 'HEALTHY') {{
                    pill.style.background = '#064e3b';
                    pill.style.borderColor = '#10b981';
                    pill.style.color = '#34d399';
                    txt.innerText = 'HEALTHY';
                }} else {{
                    pill.style.background = '#7f1d1d';
                    pill.style.borderColor = '#ef4444';
                    pill.style.color = '#f87171';
                    txt.innerText = d.status;
                }}
            }} catch(e) {{}}
        }}

        async function triggerStress(type) {{
            if (type === 'cpu') fetch('/stress/cpu', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify({{enable:true}})}});
            if (type === 'latency') fetch('/stress/latency', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify({{seconds:5.5}})}});
            setTimeout(updateMetrics, 500);
        }}
        async function triggerOutage() {{
            fetch('/simulate/outage', {{method:'POST'}});
            setTimeout(updateMetrics, 500);
        }}
        async function triggerRecover() {{
            fetch('/simulate/recover', {{method:'POST'}});
            setTimeout(updateMetrics, 500);
        }}
        function toggleJson() {{
            const box = document.getElementById('jsonBox');
            box.style.display = box.style.display === 'block' ? 'none' : 'block';
        }}

        setInterval(updateMetrics, 1500);
    </script>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    local_ip = get_local_ip()
    print(f"[TRAFFIC INGRESS] {SERVER_ID} (Port {SERVER_PORT}) served Request #{simulation_state['total_requests']} at {time.strftime('%H:%M:%S')}")

    json_payload = {
        "message": f"Cloud Outage Prediction Target Node - {SERVER_ID}",
        "server_name": SERVER_ID,
        "server_id": SERVER_ID,
        "role": SERVER_ROLE,
        "is_primary": IS_PRIMARY,
        "server_port": SERVER_PORT,
        "port": SERVER_PORT,
        "local_ip": local_ip,
        "total_requests": simulation_state["total_requests"],
        "requests_served": simulation_state["total_requests"],
        "active_requests": simulation_state["active_requests"],
        "timestamp": time.time()
    }

    # If client specifically asks for JSON (e.g. curl / API request)
    accept_hdr = request.headers.get("Accept", "")
    if "application/json" in accept_hdr or request.args.get("format") == "json":
        return jsonify(json_payload)

    # Otherwise render HTML Dashboard UI for browser requests
    cpu = psutil.cpu_percent(interval=None)
    mem = psutil.virtual_memory().percent
    lat_ms = round(simulation_state["latency_seconds"] * 1000.0, 1)

    html_content = HTML_INDEX_TEMPLATE.format(
        server_id=SERVER_ID,
        role=SERVER_ROLE,
        server_port=SERVER_PORT,
        total_requests=simulation_state["total_requests"],
        cpu=round(cpu, 1),
        memory=round(mem, 1),
        latency=lat_ms,
        raw_json=json.dumps(json_payload, indent=2)
    )
    return Response(html_content, mimetype="text/html")

@app.route("/metrics", methods=["GET"])
def prometheus_metrics():
    get_metrics()
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)

# --- CHAOS SIMULATION CONTROL ENDPOINTS ---

@app.route("/stress/cpu", methods=["POST"])
def stress_cpu():
    data = request.get_json(silent=True) or {}
    enable = data.get("enable", not simulation_state["cpu_active"])
    simulation_state["cpu_active"] = enable
    
    if enable:
        for _ in range(4):
            t = threading.Thread(target=cpu_stress_worker, daemon=True)
            t.start()
            
    return jsonify({"status": "OK", "cpu_stress_active": simulation_state["cpu_active"], "server_id": SERVER_ID})

@app.route("/stress/ram", methods=["POST"])
def stress_ram():
    data = request.get_json(silent=True) or {}
    mb = data.get("mb", 200)
    
    if mb > 0:
        chunk = bytearray(50 * 1024 * 1024)
        for _ in range(max(1, mb // 50)):
            simulation_state["ram_allocated"].append(chunk)
    else:
        simulation_state["ram_allocated"].clear()
        
    return jsonify({
        "status": "OK",
        "ram_allocated_mb": len(simulation_state["ram_allocated"]) * 50,
        "server_id": SERVER_ID
    })

@app.route("/stress/disk", methods=["POST"])
def stress_disk():
    data = request.get_json(silent=True) or {}
    mb = data.get("mb", 100)
    
    if mb > 0:
        temp_dir = tempfile.gettempdir()
        dummy_file = os.path.join(temp_dir, f"outage_stress_{SERVER_ID}_{SERVER_PORT}.tmp")
        with open(dummy_file, "wb") as f:
            f.write(b"0" * (mb * 1024 * 1024))
        simulation_state["disk_allocated_mb"] = mb
    else:
        temp_dir = tempfile.gettempdir()
        dummy_file = os.path.join(temp_dir, f"outage_stress_{SERVER_ID}_{SERVER_PORT}.tmp")
        if os.path.exists(dummy_file):
            try:
                os.remove(dummy_file)
            except Exception:
                pass
        simulation_state["disk_allocated_mb"] = 0
        
    return jsonify({"status": "OK", "disk_allocated_mb": simulation_state["disk_allocated_mb"], "server_id": SERVER_ID})

@app.route("/stress/latency", methods=["POST"])
def stress_latency():
    data = request.get_json(silent=True) or {}
    seconds = float(data.get("seconds", 5.5))
    simulation_state["latency_seconds"] = max(0.0, seconds)
    return jsonify({"status": "OK", "latency_seconds": simulation_state["latency_seconds"], "server_id": SERVER_ID})

@app.route("/stress/error", methods=["POST"])
def stress_error():
    data = request.get_json(silent=True) or {}
    rate = float(data.get("rate", 0.35))
    simulation_state["error_rate"] = max(0.0, min(1.0, rate))
    return jsonify({"status": "OK", "error_rate": simulation_state["error_rate"], "server_id": SERVER_ID})

@app.route("/simulate/outage", methods=["POST"])
def simulate_outage():
    simulation_state["is_outage"] = True
    return jsonify({"status": "OUTAGE_TRIGGERED", "server_id": SERVER_ID, "port": SERVER_PORT})

@app.route("/simulate/recover", methods=["POST"])
def simulate_recover():
    simulation_state["cpu_active"] = False
    simulation_state["ram_allocated"].clear()
    simulation_state["disk_allocated_mb"] = 0
    simulation_state["latency_seconds"] = 0.0
    simulation_state["error_rate"] = 0.0
    simulation_state["is_outage"] = False
    
    temp_dir = tempfile.gettempdir()
    dummy_file = os.path.join(temp_dir, f"outage_stress_{SERVER_ID}_{SERVER_PORT}.tmp")
    if os.path.exists(dummy_file):
        try:
            os.remove(dummy_file)
        except Exception:
            pass
            
    return jsonify({"status": "RECOVERED_HEALTHY", "server_id": SERVER_ID, "port": SERVER_PORT})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=SERVER_PORT, debug=False)
